# Data Extraction Project with n8n

This project demonstrates how to use n8n to automate the process of extracting data from an API and saving it into a database or file.

## Steps:

1. Download and install n8n from [https://n8n.io/](https://n8n.io/).
2. Import the workflow from `/workflow/workflow.json`.
3. Configure the nodes for API requests and storage.
4. Execute the workflow to extract and save data.
