# Streamlit Dashboard

This project creates a simple dashboard to visualize data using Streamlit.

## Setup Instructions

1. Install the required dependencies:
    ```bash
    pip install -r requirements.txt
    ```

2. Run the Streamlit app:
    ```bash
    streamlit run app.py
    ```

3. The dashboard will open in your browser. You can interact with the displayed data.
