# Web Scraping Project

This project scrapes product data from a website and stores it in a CSV file using Selenium and pandas.

## Setup Instructions

1. Install the required dependencies:
    ```bash
    pip install -r requirements.txt
    ```

2. Run the scraper:
    ```bash
    python scraper.py
    ```

3. The scraped data will be saved in `data/products.csv`.
