# Weather API Integration

This project integrates with the OpenWeatherMap API to fetch weather data for a specified city.

## Setup Instructions

1. Install the required dependencies:
    ```bash
    pip install -r requirements.txt
    ```

2. Run the script:
    ```bash
    python weather_api.py
    ```

3. You will get the current weather and temperature for the specified city.
