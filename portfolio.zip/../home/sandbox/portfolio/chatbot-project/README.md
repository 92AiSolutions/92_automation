# Chatbot Project

This project creates a simple chatbot using FastAPI and integrates with OpenAI's GPT API to provide responses.

## Setup Instructions

1. Install the required dependencies:
    ```bash
    pip install -r requirements.txt
    ```

2. Run the FastAPI server:
    ```bash
    uvicorn chatbot:app --reload
    ```

3. Access the chatbot at `http://127.0.0.1:8000/docs`.

## Test the API:
POST to `/chat/` with a `query` parameter to get a response from the chatbot.
